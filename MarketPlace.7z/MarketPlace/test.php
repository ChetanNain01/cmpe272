<?php

?>

<html>

<body onload="getConfig()">
    <script src="js/config.js"></script>
</body>

</html>